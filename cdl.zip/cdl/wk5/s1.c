#include<stdio.h>
int main(){
	int a=5;
	char b='d';
	printf("a=%d\n",a);
	printf("%c",b);
}
