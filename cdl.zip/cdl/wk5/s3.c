#include<stdio.h>
int main(){
	int i=0;
	for(i=0;i<5;i++){
		smt1;
		for(int j=0;j<10;j++){
			smt;
		}
		smt2;
	}
}
