#include<stdio.h>
int main(){
	int a=7;
	if(a>5) 
		if(a<10){ printf("a");} 
	else printf("b");
