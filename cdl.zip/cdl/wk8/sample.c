switch(a){
	case 1:
		a=a+2;
		break;
	case 2:
		a=a+3;
		break;
//	default:
		a=a+5;
		break;
}
