for(i=1;i<7;i=i+1){a=a+1;}
