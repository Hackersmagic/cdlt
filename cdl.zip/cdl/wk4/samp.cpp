#include<iostream>
using namespace std;
int main(){
	int a=0;
	int b=2;
	int c=++a+ ++b;
	int d=a+b;
	int e=-a+b++;
	int f=-c*d;
	int g=c/d*(-a);
	int h=a- -c;
}
