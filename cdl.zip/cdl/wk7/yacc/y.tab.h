#define A 257
#define B 258
#define NL 259
