#include<stdio.h>
int main(){
	int i,sum=0;
	int arr[10]={1,2,3,4,5,6,7,8,9,10};
	i=0;
start:
    if(i<10){
		sum+=arr[i];
	
i++;
    goto start;
}else{goto remaining;
}
remaining:
	printf("the sum is %d\n",sum);
}
