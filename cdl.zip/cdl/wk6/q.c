#include<stdio.h>
int main(){
	int i=0,j;
start:
	if(i<2){
		printf("hello");
		j=0;
		goto start1;

	}
	else{
		goto end;
	}
start1:
		if(j<3){
			printf("hi");
			j++;
			goto start1;
		}
		else{
			i++;
			goto start;
		}
end:
		return 0;
}
