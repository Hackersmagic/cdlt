#include<stdio.h>
int main(){
	int i=0;
	int n=5;
	for(i=0;i<n;i++){
		printf("hello");
	}
}
