#include<stdio.h>
int main(){
	int i=0;
	start:
            if(i<5){
		printf("hello");
		i++;
	
       goto start;
}}
