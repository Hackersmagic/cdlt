int i=0;
int j=0;
for(i=0;i<3;i++){
for(j=0;j<3;j++){
smt;}}
