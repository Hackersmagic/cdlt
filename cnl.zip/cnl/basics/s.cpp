#include<iostream>
#include<sys/socket.h>
#include<netinet/in.h>
#include<stdlib.h>
#include<string>
#include<cstring>
#include<unistd.h>
#define PORT 55146
using namespace std;
struct Data
{
	int no;
	char name[50];
};
void communicate(int connfd)
{
	Data res;
	cout<<"Communication function started ..."<<endl;
	recv(connfd,&res,sizeof(res),0);

	cout<<"Data recieved from the client : "<<endl;
	cout<<"No : "<<res.no<<endl;
	cout<<"Name : "<<res.name<<endl;


	res.no = res.no*res.no;
	strcat(res.name," Welcome");

	send(connfd,&res,sizeof(res),0);
}

int main()
{

	int sockfd,connfd;
	socklen_t clilen;
	sockaddr_in servaddr,cliaddr;

	sockfd = socket(AF_INET,SOCK_STREAM,0);

	if(sockfd == -1)
	{
		cout<<"\nSocket creation failed ! "<<endl;
		return 1;
	}
	else
		cout<<"\nSocket created successfully"<<endl;

	
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(PORT);

	if(bind(sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr))<0)
	{
		cout<<"\nSocket binding failed!"<<endl;
		return 1;
	}
	else
		cout<<"\nSocket binded successfully"<<endl;

	if(listen(sockfd,5)<0)
	{
		cout<<"\nListen failed!"<<endl;
		return 1;
	}
	else
	{
		cout<<"\nServer listening"<<endl;

	clilen = sizeof(cliaddr);
	connfd = accept(sockfd,(struct sockaddr*)&cliaddr,&clilen);

	if(connfd<0)
	{
		cout<<"server accept failed!"<<endl;
		return 1;
	}
	else
	{
		cout<<"Server accepted the client"<<endl;
		communicate(connfd);
	}
	}
	close(connfd);
	close(sockfd);
}
