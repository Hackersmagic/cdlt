#include<iostream>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include<unistd.h>
#include<cstring>

#define PORT 55146
using namespace std;
typedef sockaddr SA;

struct Data
{
	int no;
	char name[50];
};
void communicate(int sockfd)
{
	Data req;
	cout<<"Enter the data to send to the server : "<<endl;
	cout<<"NO : ";
	cin>>req.no;

	cout<<endl<<"Name : ";
	cin>>req.name;

	send(sockfd,&req,sizeof(req),0);

	cout<<endl<<"Data is sent to the server"<<endl;

	recv(sockfd,&req,sizeof(req),0);

	cout<<"Data recieved from the server : "<<endl;
	cout<<"No : "<<req.no<<endl;
	cout<<"Name : "<<req.name<<endl;
}
int main()
{
	int sockfd;
	sockaddr_in servaddr;

	sockfd = socket(AF_INET,SOCK_STREAM,0);

	if(sockfd<0)
	{
		cout<<"Socket creation failed!"<<endl;
		return 1;
	}
	else
	{
		cout<<"Socket created successfully"<<endl;
	}

	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(PORT);

	if(connect(sockfd,(SA*)&servaddr,sizeof(servaddr))<0)
	{
		cout<<"Connection failed!"<<endl;
		return 1;
	}
	else
	{
		communicate(sockfd);
	}
	close(sockfd);
}
