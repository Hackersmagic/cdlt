#include<iostream>
#include<netinet/in.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<stdlib.h>
#include<cstring>
#include<string>

using namespace std;
int PORT = 53046;
typedef sockaddr SA;

struct Data
{
	int roll;
	char name[100];
	char mobile[50];
};
void communicate(int connfd)
{
	for(;;)
	{
		Data res;

		recv(connfd,&res,sizeof(res),0);

		cout<<"Data recieved from the client : "<<endl;
		cout<<"Roll no : "<<res.roll<<endl;
		cout<<"Name : "<<res.name<<endl;
		cout<<"mobile : "<<res.mobile<<endl;
	}

}
int main(int argc,char *argv[])
{
	if(argc == 2)
		PORT = atoi(argv[1]);
	int sockfd,connfd;
	sockaddr_in servaddr,cliaddr;
	socklen_t clilen;

	sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd == -1)
	{
		cout<<"Socket creation failed!"<<endl;
		return 1;
	}
	else
		cout<<"Socket created successfully"<<endl;

	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(PORT);

	if(bind(sockfd,(SA*)&servaddr,sizeof(servaddr))<0)
	{
		cout<<"Socket binding failed!"<<endl;
		return 1;
	}
	else
		cout<<"Socket binded successfully"<<endl;

	if(listen(sockfd,3)<0)
	{
		cout<<"Listen failed"<<endl;
		return 1;
	}
	else
	{
		cout<<"Server listening..."<<endl;
		clilen = sizeof(cliaddr);
		connfd = accept(sockfd,(SA*)&cliaddr,&clilen);

		if(connfd<0)
		{
			cout<<"Accept failed!"<<endl;
			return 1;
		}
		else
		{
			cout<<"Server accepted the client"<<endl;
			communicate(connfd);
		}
	}
	close(connfd);
	close(sockfd);
}
