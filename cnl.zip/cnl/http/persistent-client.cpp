#include<iostream>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<stdlib.h>
#include<unistd.h>
#include<cstring>
#include<string>

using namespace std;
int PORT = 53046;
typedef sockaddr SA;

struct Data
{
	int roll;
	char name[100];
	char mobile[50];
};
void communicate(int sockfd)
{
	for(;;)
	{
		Data req;
		string temp;
		cout<<"Enter the data : "<<endl;
		cout<<"Roll : ";
		getline(cin,temp);
		strcpy(req.name,temp.c_str());
		cout<<endl<<"name : ";
		cin>>req.name;
		cout<<endl<<"Mobile : ";
		cin>>req.mobile;

		send(sockfd,&req,sizeof(req),0);
		cout<<"Data sent to the server!"<<endl;
	}
}
int main(int argc, char *argv[])
{
	if(argc == 2)
		PORT = atoi(argv[1]);

	int sockfd;
	sockaddr_in servaddr;

	sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd == -1)
	{
		cout<<"Socket creation failed!"<<endl;
		return 1;
	}
	else
		cout<<"Socket created successfully"<<endl;

	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(PORT);

	if(connect(sockfd,(SA*)&servaddr,sizeof(servaddr))<0)
	{
		cout<<"Connection failed!"<<endl;
		return 1;
	}
	else
	{
		cout<<"Client connected to server "<<endl;
		communicate(sockfd);
	}
	close(sockfd);
}
