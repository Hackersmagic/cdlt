#include<iostream>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<cstring>
#include<string>
#include<stdlib.h>
#include<unistd.h>
using namespace std;
int PORT = 53046;
typedef sockaddr SA;

void communicate(int connfd1, int connfd2)
{
	for(;;)
	{
		char message[100];

		string temp;
		recv(connfd1,&message,sizeof(message),0);

		if(strcmp(message,"exit") == 0)
		{
			send(connfd2,&message,sizeof(message),0);
			exit(0);
		}
		cout<<"Message from Alice : "<<message<<endl;

		int choice;
		cout<<"Enter (0) to send the message and (1) to alter the message : "<<endl;
		cin>>choice;

		switch(choice)
		{
			case 1:
				cout<<endl<<"Your message to Bob : ";
				getline(cin,temp);
				strcpy(message,temp.c_str());
				send(connfd2,&message,sizeof(message),0);
				break;
			case 0:
				send(connfd2,&message,sizeof(message),0);
				break;
			default:
				cout<<"Invalid choice!"<<endl;
				break;
		}

		cout<<"Message sent to Bob"<<endl;

		recv(connfd2,&message,sizeof(message),0);

		cout<<"Message from Bob : "<<message<<endl;

		cout<<endl<<"Enter (0) to send the message and (1) to alter the message : "<<endl;
		cin>>choice;

		switch(choice)
		{
			case 1:
				cout<<endl<<"Your Reply to Alice : ";
				getline(cin,temp);
				strcpy(message,temp.c_str());
				send(connfd1,&message,sizeof(message),0);
				break;
			case 0:
				send(connfd1,&message,sizeof(message),0);
				break;
			default:
				cout<<"Invalid choice!"<<endl;
		}
//		send(connfd1,&message,sizeof(message),0);

		cout<<"Reply sent to Alice"<<endl;

	}
}
int main(int argc,char *argv[])
{
	if(argc > 1)
		PORT = atoi(argv[1]);
	int sockfd,connfd1,connfd2;
	sockaddr_in servaddr,cliaddr1,cliaddr2;
	socklen_t clilen1,clilen2;

	sockfd = socket(AF_INET,SOCK_STREAM,0);

	if(sockfd == -1)
	{
		cout<<"Socket creation failed!"<<endl;
		return 1;
	}
	else
		cout<<"Socket created successfully"<<endl;

	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(PORT);

	if(bind(sockfd,(SA*)&servaddr,sizeof(servaddr))<0)
	{
		cout<<"Socket binding failed!"<<endl;
		return 1;
	}
	else
		cout<<"Socket binded successfully"<<endl;


	if(listen(sockfd,3)<0)
	{
		cout<<"Listen failed"<<endl;
		return 1;
	}
	else
	{
		cout<<"Server is listening"<<endl;

		clilen1 = sizeof(cliaddr1);
		connfd1 = accept(sockfd,(SA*)&cliaddr1,&clilen1);
		if(connfd1<0)
		{
			cout<<"Client 1 connection failed!"<<endl;
			return 1;
		}
		else
		{
			cout<<"Client 1 connected successfully"<<endl;

			clilen2 = sizeof(cliaddr2);
			connfd2 = accept(sockfd,(SA*)&cliaddr2,&clilen2);
			if(connfd2<0)
			{
				cout<<"Client 2 connection failed!"<<endl;
				return 1;
			}
			else
			{
				cout<<"Client 2 connected successfully"<<endl;
				communicate(connfd1,connfd2);
			}

		}
	}
	close(connfd1);
	close(connfd2);
	close(sockfd);
}
