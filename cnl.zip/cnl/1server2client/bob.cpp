#include<iostream>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<stdlib.h>
#include<cstring>
#include<string.h>

using namespace std;
int PORT = 53046;
typedef sockaddr SA;

void communicate(int sockfd)
{
	for(;;)
	{
		char message[100];
		string temp;

		recv(sockfd,&message,sizeof(message),0);
		if(strcmp(message,"exit") == 0)
		{
			exit(0);
		}

		cout<<"Message from Alice : "<<message<<endl;

		cout<<"Your Reply : ";
		getline(cin,temp);
		strcpy(message,temp.c_str());

		send(sockfd,&message,sizeof(message),0);

	}
}
int main(int argc,char* argv[])
{
	if(argc == 2)
		PORT = atoi(argv[1]);
	int sockfd;
	sockaddr_in servaddr;

	sockfd = socket(AF_INET,SOCK_STREAM,0);

	if(sockfd == -1)
	{
		cout<<"Socket creation failed!"<<endl;
		return 1;
	}
	else
		cout<<"Socket created successfully"<<endl;


	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(PORT);

	if(connect(sockfd,(SA*)&servaddr,sizeof(servaddr))<0)
	{
		cout<<"Connection failed!"<<endl;
		return 1;
	}
	else
	{
		cout<<"Bob connected"<<endl;
		communicate(sockfd);
	}
	close(sockfd);
}
