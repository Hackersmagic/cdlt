#include<iostream>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<cstring>
#include<string>

using namespace std;
int PORT = 53046;
typedef sockaddr SA;

struct clientdata
{
	char domain[100];
};
struct rootdata
{
	int n;
	char domain[10];
};
struct tlddata
{
	int n;
	char domain[100];
};
int main()
{
	int  lsockfd,clifd,rootfd,tldfd;
	sockaddr_in lservaddr,cliaddr,rootaddr,tldaddr;
	socklen_t clilen,rootlen,tldlen;
	lsockfd = socket(AF_INET,SOCK_STREAM,0);
	if(lsockfd == -1)
	{
		cout<<"Socket creation failed!"<<endl;
		return 1;
	}
	else
		cout<<"Socket created"<<endl;

	lservaddr.sin_family = AF_INET;
	lservaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	lservaddr.sin_port = htons(PORT);

	if(bind(lsockfd,(SA*)&lservaddr,sizeof(lservaddr))<0)
	{
		cout<<"Binding failed!"<<endl;
		return 1;
	}
	else
		cout<<"Socket binded successfully"<<endl;

	if(listen(lsockfd,5)<0)
	{
		cout<<"listen failed!"<<endl;
		return 1;
	}
	else
	{
		cout<<"Server is listening for client"<<endl;

		clilen = sizeof(cliaddr);
		clifd = accept(lsockfd,(SA*)&cliaddr,&clilen);
		if(clifd<0)
		{
			cout<<"Client accept failed!"<<endl;
			return 1;
		}
		else
		{
			clientdata cli;
			cout<<"accepted client"<<endl;
			recv(clifd,&cli,sizeof(cli),0);

			char temp[100];
			strcpy(temp,cli.domain);
			char *before_dot = strtok(temp,".");
			char *after_dot = strtok(NULL,".");

			cout<<"Domain : "<<after_dot<<endl;

			rootdata rt;
			strcpy(rt.domain,after_dot);

			cout<<"Connected to root server: "<<endl;
			rootlen = sizeof(rootaddr);
			rootfd = accept(lsockfd,(SA*)&rootaddr,&rootlen);
			if(rootfd<0)
			{
				cout<<"Root server failed"<<endl;
				return 1;
			}
			else
			{
				cout<<"Root server connected"<<endl;
				send(rootfd,&rt,sizeof(rt),0);
				cout<<rt.domain<<" sent to root server "<<endl;

				recv(rootfd,&rt,sizeof(rt),0);

				tldlen = sizeof(tldaddr);
				tldfd = accept(lsockfd,(SA*)&tldaddr,&tldlen);

				if(tldfd<0)
				{
					cout<<"TLD server failed!"<<endl;
					return 1;
				}
				else
				{
					cout<<"Connected to TLD Server"<<endl;
					cout<<"Before Dot"<<before_dot<<endl;

					tlddata tl;
					tl.n = rt.n;
					strcpy(tl.domain,before_dot);

					send(tldfd,&tl,sizeof(tl),0);
					cout<<"Data sent to TLD server "<<endl;

					char ip[100];
					recv(tldfd,&ip,sizeof(ip),0);
					cout<<"Ip got : "<<ip;

					strcpy(cli.domain,ip);

					send(clifd,&cli,sizeof(cli),0);
				}
			}
		}
	}
}
