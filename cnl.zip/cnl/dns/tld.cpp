#include<iostream>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include<unistd.h>
#include<cstring>
#include<map>

using namespace std;
int PORT = 53046;
typedef sockaddr SA;
struct Data
{
	int n;
	char domain[100];
};
void communicate(int sockfd)
{
	char ip[100];

	map<string,string> dict1,dict2,dict3,dict4;

	dict1["google"] = "10.5.12.224";
	dict1["amazon"] = "12.5.12.224";
	dict1["facebook"] = "10.5.12.224";
	dict2["annauniv"] = "10.5.12.224";
	dict2["avp"] = "11.5.12.224";
	dict3["kali"] = "10.7.12.224";
	dict3["zorin"] = "15.6.11.124";
	dict4["amazon"] = "13.5.12.224";
	dict4["flipkart"] = "20.5.12.224";
	dict4["instagram"] = "192.5.12.224";
	dict4["wexford"] = "191.51.12.224";

	Data req;

	recv(sockfd,&req,sizeof(req),0);

	cout<<"Recieved domain : "<<req.n<<endl;
	cout<<"Recieved address : "<<req.domain<<endl;

		if (req.n == 1)
		{
			auto it = dict1.find(req.domain);
			if(it != dict1.end())
				strcpy(ip,it->second.c_str());
			else
				strncpy(ip,"IP not found",13);
		}
		else if(req.n == 2)
		{
			auto it = dict2.find(req.domain);
			if(it != dict2.end())
				strcpy(ip,it->second.c_str());
			else
				strncpy(ip,"IP not found",13);
		}
		else if(req.n == 3)
		{
			auto it = dict3.find(req.domain);
			if(it != dict3.end())
				strcpy(ip,it->second.c_str());
			else
				strncpy(ip,"IP not found",13);
		}
		else if(req.n == 4)
		{
			auto it = dict4.find(req.domain);
			if(it != dict4.end())
				strcpy(ip,it->second.c_str());
			else
				strncpy(ip,"IP not found",13);
		}
		else
		{
			strncpy(ip,"IP not found",13);
		}
		send(sockfd,&ip,sizeof(ip),0);
		cout<<"Data sent to local server"<<endl;
}
int main(int argc,char *argv[])
{
	if(argc == 2)
		PORT = atoi(argv[1]);
	int sockfd;
	sockaddr_in servaddr;

	sockfd = socket(AF_INET,SOCK_STREAM,0);

	if(sockfd<0)
	{
		cout<<"Socket creation failed!"<<endl;
		return 1;
	}
	else
	{
		cout<<"Socket created successfully"<<endl;
	}

	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(PORT);

	if(connect(sockfd,(SA*)&servaddr,sizeof(servaddr))<0)
	{
		cout<<"Connection failed!"<<endl;
		return 1;
	}
	else
	{
		communicate(sockfd);
	}
	close(sockfd);
}
