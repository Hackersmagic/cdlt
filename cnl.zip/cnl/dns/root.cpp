#include<iostream>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<stdlib.h>
#include<unistd.h>
#include<cstring>
#include<map>

using namespace std;
int PORT = 53046;
typedef sockaddr SA;
struct Data
{
	int n;
	char domain[10];
};
void communicate(int sockfd)
{

	map<string,int> domain;

	domain["com"] = 1;
	domain["edu"] = 2;
	domain["org"] = 3;
	domain["in"] = 4;

	Data req;

	recv(sockfd,&req,sizeof(req),0);

	cout<<"Recieved domain : "<<req.domain<<endl;

	auto it = domain.find(req.domain);

	if(it != domain.end())
	{
		req.n = it->second;
	}
	else
		req.n = -1;

	send(sockfd,&req,sizeof(req),0);
	cout<<"result sent to local server"<<endl;
}
int main(int argc,char *argv[])
{
	if(argc == 2)
		PORT = atoi(argv[1]);
	int sockfd;
	sockaddr_in servaddr;

	sockfd = socket(AF_INET,SOCK_STREAM,0);

	if(sockfd<0)
	{
		cout<<"Socket creation failed!"<<endl;
		return 1;
	}
	else
	{
		cout<<"Socket created successfully"<<endl;
	}

	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(PORT);

	if(connect(sockfd,(SA*)&servaddr,sizeof(servaddr))<0)
	{
		cout<<"Connection failed!"<<endl;
		return 1;
	}
	else
	{
		communicate(sockfd);
	}
	close(sockfd);
}
