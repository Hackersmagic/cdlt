import java.io.*;
import java.net.*;
public class Client{
	public static void main(String[] args){
		try{
		Socket client = new Socket("127.0.0.1");
		System.out.println("client is connected");
		// read data from the server
		BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream()));
		}
		catch(Exception e){
			System.out.println(e);}
	}
}
			
