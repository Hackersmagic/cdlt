#include<stdio.h>

#include <stdlib.h>

#include <string.h>

#include <unistd.h>

#include <arpa/inet.h>



#define PORT 3036

#define BUF_SIZE 1024



int main() {

    int sock = 0;

    struct sockaddr_in serv_addr;

    char buffer[BUF_SIZE] = {0};

    char ack[BUF_SIZE] = {0};

    char *message;



    // Creating socket file descriptor

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {

        printf("\nSocket creation error\n");

        return -1;

    }



    serv_addr.sin_family = AF_INET;

    serv_addr.sin_port = htons(PORT);



    // Convert IPv4 and IPv6 addresses from text to binary form

    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {

        printf("\nInvalid address/ Address not supported\n");

        return -1;

    }



    // Connect to the server

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {

        printf("\nConnection Failed\n");

        return -1;

    }



    while (1) {

        printf("Type a message to send (type 'exit' to quit): ");

        fgets(buffer, BUF_SIZE, stdin);

        buffer[strcspn(buffer, "\n")] = 0;  // Remove the newline character from input



        // Exit if user types "exit"

        if (strcmp(buffer, "exit") == 0) {

            printf("Exiting...\n");

            break;

        }



        message = buffer;



        // Send message to server

        send(sock, message, strlen(message), 0);

        printf("Message sent to server: %s\n", message);



        // Wait for acknowledgment from server

        memset(ack, 0, BUF_SIZE);  // Clear buffer for acknowledgment

        int bytes_received = read(sock, ack, BUF_SIZE);

        if (bytes_received < 0) {

            perror("Error receiving ACK");

            break;

        }



        printf("Acknowledgment received from server: %s\n", ack);

    }



    close(sock);

    return 0;

}
