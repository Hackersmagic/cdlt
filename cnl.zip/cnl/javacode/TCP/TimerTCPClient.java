import java.io.*;
import java.net.*;
public class TimerTCPClient{
	public static void main(String[] args){
		String ServerAddress ="localhost";
		int port= 5437;
		try(Socket socket = new Socket(ServerAddress,port);
		PrintWriter out = new PrintWriter(socket.getOutputStream(),true);
		BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))){
		BufferedReader userInput= new BufferedReader(new InputStreamReader(System.in));
		String userInputLine;
		System.out.println("Connected to the server.Type msg to send");
                while(userInput != null)		{
			userInputLine = userInput.readLine();
			System.out.println(userInput);
			String response=in.readLine();
			System.out.println("Server" + response);
		}
		}
		catch(IOException e){
			System.out.println(e);
		}
}
}
