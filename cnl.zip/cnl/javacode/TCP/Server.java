import java.io.*;
import java.net.*;
import java.util.*;
public class Server{
	public static void main(String[] args){
		try{
		ServerSocket ss = new ServerSocket("127.0.0.1");
		Socket server = ss.accept();
		System.out.println("Server is connected...");
		//send msg from server
		Scanner sc = new Scanner(System.in);
		PrintWritter pr = new PrintWriter(server.getOutputStream());
		while(true){
			System.out.println("enter data:");
			String data = sc.nextInt();
			System.out.println("Data from"+data);
		pr.println(data);
		pr.flush();
		}
		catch(Exception e){
			System.out.println(e);
	}
}
