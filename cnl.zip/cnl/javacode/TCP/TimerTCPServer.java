import java.io.*;
import java.net.*;

public class TimerTCPServer {
    public static void main(String[] args) {
       int port = 5437; // Port number to listen on

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is listening on port " + port);

            while (true) {
                Socket socket = serverSocket.accept(); // Accept incoming connections
                System.out.println("New client connected");

                // Create a new thread for each client
                new ClientHandler(socket).start();
            }
        } catch (IOException e) {
            System.out.println("Error in server: " + e.getMessage());
        }
    }
}

class ClientHandler extends Thread {
    private Socket socket;
    private static final int TIME_LIMIT = 10; // Time limit in seconds

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        try (
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        ) {
            long startTime = System.currentTimeMillis();

            // Start a timer thread
            new Thread(() -> {
                while (true) {
                    long elapsedTime = (System.currentTimeMillis() - startTime) / 1000; // Convert to seconds
                    if (elapsedTime >= TIME_LIMIT) {
                        try {
                            out.println("You have been connected for " + TIME_LIMIT + " seconds. Disconnecting now.");
                            socket.close();
                        } catch (IOException e) {
                            System.out.println("Error closing socket: " + e.getMessage());
                        }
                        break;
                    }
                    try {
                        Thread.sleep(1000); // Check every second
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            }).start();

	    String inputLine;
	    while((inputLine=in.readLine()) != null){ 
                System.out.println("Received from client: " + inputLine);
                out.println("Echo: " + inputLine); // Echo the message back to the client
            }
        } catch (IOException e) {
            System.out.println("Error in client handler: " + e.getMessage());
        } finally {
            try {
                socket.close();
                System.out.println("Client disconnected");
            } catch (IOException e) {
                System.out.println("Error closing socket: " + e.getMessage());
            }
        }
    }
}

