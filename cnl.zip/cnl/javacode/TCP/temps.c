#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <unistd.h>

#include <arpa/inet.h>

#include <sys/time.h>



#define PORT 53036

#define BUF_SIZE 1024

#define TIMEOUT 5  // 5 seconds timeout



int main() {

    int sock = 0;

    struct sockaddr_in serv_addr;

//    char buffer[BUF_SIZE] = {0};

    char message[BUF_SIZE] = "Hello from Client!";

    char ack[BUF_SIZE] = {0};

    struct timeval tv;



    // Creating socket file descriptor

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {

        printf("\nSocket creation error\n");

        return -1;

    }



    serv_addr.sin_family = AF_INET;

    serv_addr.sin_port = htons(PORT);



    // Convert IPv4 and IPv6 addresses from text to binary form

    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {

        printf("\nInvalid address/ Address not supported\n");

        return -1;

    }



    // Connect to the server

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {

        printf("\nConnection Failed\n");

        return -1;

    }



    // Set the timeout for receiving ACKs

    tv.tv_sec = TIMEOUT;  // Set timeout (seconds)

    tv.tv_usec = 0;       // Set timeout (microseconds)

    

    // Apply the timeout to the socket using setsockopt()

    if (setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(tv)) < 0) {

        perror("Error setting timeout");

        return -1;

    }



    while (1) {

        // Send message to server
        printf("Type a message to send (type 'exit' to quit): ");         
	fgets(message, BUF_SIZE, stdin);                                                                        message[strcspn(message, "\n")] = 0;  	
	printf("Message sent to server: %s\n", message);
	if(strcmp(message,"exit")==0){break;}
	while(message!="exit")
	{
	send(sock, message, strlen(message), 0);




        // Wait for acknowledgment from server

        memset(ack, 0, BUF_SIZE);

        int bytes_received = recv(sock, ack, BUF_SIZE, 0);



        if (bytes_received < 0) {

            // Timeout or error occurred (no ACK received)

            perror("ACK not received, resending message...");

            // Resend the same message (Stop-and-Wait resend logic)

            continue;

        } else if (bytes_received == 0) {

            // Server has closed the connection

            printf("Connection closed by server\n");

            break;

        } else {

            // Acknowledgment received

            printf("Acknowledgment received from server: %s\n", ack);
	    break;

        }
	}




      }

    close(sock);

    return 0;

}
