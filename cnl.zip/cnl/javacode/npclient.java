import java.io.*;
import java.net.*;

public class SimpleHttpClient {
    public static void main(String[] args) {
        String host = "localhost";
        int port = 54321; // Port where the server is running

        try {
            for (int i = 0; i < 3; i++) { // Sending 3 requests
                System.out.println("Sending request " + (i + 1));
                try (Socket socket = new Socket(host, port)) {
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                    // Send the HTTP GET request
                    out.println("GET / HTTP/1.1");
                    out.println("Host: " + host);
                    out.println("Connection: close");
                    out.println(); // Blank line to indicate end of headers

                    // Read the response
                    String line;
                    while ((line = in.readLine()) != null) {
                        System.out.println(line);
                    }

                    System.out.println();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

