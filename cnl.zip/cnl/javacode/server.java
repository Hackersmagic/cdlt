import java.io.*;
import java.net.*;

public class SimpleServer {
	    public static void main(String[] args) {
		            int port = 54321; // Port number
			            try (ServerSocket serverSocket = new ServerSocket(port)) {
					                System.out.println("Server is listening on port " + port);
							            
							            while (true) {
									                    Socket socket = serverSocket.accept(); // Accept incoming connections
											                    System.out.println("New client connected");

													                    // Handle the client in a new thread
															                 new ClientHandler(socket).start();
															                                 }
															                                         } catch (IOException e) {
															                                                     System.out.println("Server exception: " + e.getMessage());
															                                                             }
															                                                                 }
															                                                                 }
															   
															                                                                 class ClientHandler extends Thread {
															                                                                     private Socket socket;
															    
															                                                                         public ClientHandler(Socket socket) {
															                                                                                 this.socket = socket;
															                                                                                     }
															    
															                                                                                         public void run() {
															                                                                                                 try (BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
															                                                                                                             PrintWriter output = new PrintWriter(socket.getOutputStream(), true)) {
															                                                                                                                          
															                                                                                                                                      String message;
															                                                                                                                                                  while ((message = input.readLine()) != null) {
															                                                                                                                                                                  System.out.println("Received: " + message);
															                                                                                                                                                                                  output.println("Echo: " + message); // Echo back the message
															                                                                                                                                                                                              }
															                                                                                                                                                                                                      } catch (IOException e) {
															                                                                                                                                                                                                                  System.out.println("Client exception: " + e.getMessage());
															                                                                                                                                                                                                                          } finally {
															                                                                                                                                                                                                                                      try {
															                                                                                                                                                                                                                                                      socket.close();
															                                                                                                                                                                                                                                                                  } catch (IOException e) {
															                                                                                                                                                                                                                                                                                  e.printStackTrace();
															                                                                                                                                                                                                                                                                                              }
															                                                                                                                                                                                                                                                                                                      }
															                                                                                                                                                                                                                                                                                                         }
															                                                                                                                                                                                                                                                                                                          }
															    
