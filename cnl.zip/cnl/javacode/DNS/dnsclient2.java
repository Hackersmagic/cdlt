import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class DNSClient {
    public static void main(String[] args) {
        String hostname = "google.com";
       int ports[] =(9800,9700)	// Change this to test different hostnames
        try {
            DatagramSocket socket = new DatagramSocket();
	    for(int port : ports){
            InetAddress serverAddress = InetAddress.getByName(""); // Assuming server is running on localhost
            byte[] buffer = hostname.getBytes();

            // Send request
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length, serverAddress, port);
            socket.send(packet);
            System.out.println("Sent request for: " + hostname+"to server on port"+port);

            // Receive response
            byte[] responseBuffer = new byte[512];
            DatagramPacket responsePacket = new DatagramPacket(responseBuffer, responseBuffer.length);
            socket.receive(responsePacket);

            String response = new String(responsePacket.getData(), 0, responsePacket.getLength());
            System.out.println("Received response from server on port: " + port +":"+ response);

            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

