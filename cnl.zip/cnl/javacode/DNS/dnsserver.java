import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class DNSServer {
    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket(53); // DNS typically uses port 53
            System.out.println("DNS Server is running...");

            while (true) {
                byte[] buffer = new byte[512];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet); // Receive request

                String request = new String(packet.getData(), 0, packet.getLength());
                System.out.println("Received request: " + request);

                // Simple logic to respond with a fixed IP address for a specific hostname
                String response = "";
                if (request.equalsIgnoreCase("example.com")) {
                    response = "93.184.216.34"; // Example IP address for example.com
                } else {
                    response = "Not found";
                }

                byte[] responseData = response.getBytes();
                DatagramPacket responsePacket = new DatagramPacket(responseData, responseData.length, packet.getAddress(), packet.getPort());
                socket.send(responsePacket); // Send response
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
