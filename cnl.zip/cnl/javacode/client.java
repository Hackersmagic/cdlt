import java.io.*;
import java.net.*;

public class SimpleClient {
	public static void main(String[] args) {
		String hostname = "localhost"; // Server address
		int port = 54321; // Server port

		try (Socket socket = new Socket(hostname, port);
				PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
				BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in))) {

			System.out.println("Connected to the server");

			String userInput;
			while ((userInput = consoleInput.readLine()) != null) {
				output.println(userInput); // Send user input to server
				String response = input.readLine(); // Read response from server
				System.out.println(response); // Print server response
			}
		} catch (IOException e) {
			System.out.println("Client exception: " + e.getMessage());
		}
	}
}

