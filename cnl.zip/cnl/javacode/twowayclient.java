import java.io.*;
import java.net.*;

public class TwoWayClient {
	public static void main(String[] args) {
		String hostname = "localhost"; // Server address
		int port = 9876; // Server port

		try (Socket socket = new Socket(hostname, port);
				PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
				BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in))) {

			System.out.println("Connected to the server");

			// Thread for reading messages from the server
			new Thread(() -> {
				try {
					String response;
					while ((response = input.readLine()) != null) {
						System.out.println(response); // Print server response
					}
				} catch (IOException e) {
					System.out.println("Server exception: " + e.getMessage());
				}
			}).start();

			// Main thread for sending messages to the server
			String userInput;
			while ((userInput = consoleInput.readLine()) != null) {
				output.println(userInput); // Send user input to server
			}
		} catch (IOException e) {
			System.out.println("Client exception: " + e.getMessage());
		}
	}
}

