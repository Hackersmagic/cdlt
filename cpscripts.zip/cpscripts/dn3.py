import requests
url = "http://raw.githubusercontent.com/Harihacks2git/dummy/main/sample.zip"
response = requests.get(url)
with open("sample.zip","wb") as file:
    file.write(response.content)

print("File Downloaded successfully":)
