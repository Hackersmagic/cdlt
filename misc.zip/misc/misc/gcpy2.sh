read -p "Enter the file name to upload : " fname
base64 $fname > $fname.b64

# Read base64-encoded content into variable
CONTENT=$(cat $fname.b64)

# GitHub repository details
REPO="Hackersmagic/cdlt"  # Change to your username/repo
BRANCH="main"             # Target branch
TOKEN="ghp_z#yhIzUshTLuhsxN8dleygWPqsQiGe20q7IT#F"  # Your GitHub token
GITHUB_API="https://api.github.com/repos/$REPO/contents/$fname"

# Check if file exists by fetching its details from GitHub
SHA=$(curl -s -H "Authorization: token $TOKEN" $GITHUB_API | jq -r '.sha')

# Create the payload.json file for the upload
if [ -z "$SHA" ] || [ "$SHA" == "null" ]; then
  echo "File doesn't exist, creating new..."
  # If file doesn't exist, no SHA is required
  echo "{\"message\": \"Uploaded $fname\", \"content\": \"$CONTENT\", \"branch\": \"$BRANCH\"}" > payload.json
else
  echo "File exists, updating..."
  # If file exists, include the SHA in the payload for update
  echo "{\"message\": \"Updated $fname\", \"content\": \"$CONTENT\", \"sha\": \"$SHA\", \"branch\": \"$BRANCH\"}" > payload.json
fi

# Use curl to send the request to upload or update the file
curl -s -X PUT -H "Authorization: token $TOKEN" \
     -H "Content-Type: application/json" \
     --data @payload.json \
     $GITHUB_API
