#!/bin/bash

id=2021103036
ip=10.5.12.254

read -p "Enter the file name to upload : " fname

scp $fname s$id@$ip:/home/s$id/.local/lib

echo "Copied successfully"
