#!/bin/bash

id=2021103036
ip=10.5.12.254

read -p "Enter the bin path to upload : " fname

scp $fname s$id@$ip:/home/s$id/.local/bin

echo "Copied successfully"
