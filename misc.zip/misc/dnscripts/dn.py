import urllib.request

url = 'https://raw.githubusercontent.com/Harihacks2git/dummy/main/sample.zip'
file_name = 'sample.zip'

with urllib.request.urlopen(url) as response:
    content = response.read()

with open(file_name, 'wb') as file:
    file.write(content)

print(f"File '{file_name}' downloaded successfully.")

