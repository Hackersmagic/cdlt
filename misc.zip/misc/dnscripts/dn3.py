import requests
url = "https://raw.githubusercontent.com/Hackersmagic/cdlt/main/cnl.zip"
response = requests.get(url)
with open("cnl.zip","wb") as file:
    file.write(response.content)

print("File Downloaded successfully")
