import http.client

conn = http.client.HTTPSConnection("raw.githubusercontent.com")
conn.request("GET","/Harihacks2git/dummy/main/sample.zip")
response = conn.getresponse()
content = response.read()
with open("sample.zip","wb") as file:
    file.write(content)
print("File downloaded successfully")
