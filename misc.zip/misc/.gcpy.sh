#!/bin/bash
read -p "Enter the file name to upload : " fname
base64 $fname > $fname.b64
{"message": "uploaded $fname", "content": "dGhlIHJlc3VsdCBpcyBub3RoaW5nIGJ1dAo="}
CONTENT=$(cat $fname.b64)
echo "{\"message\": \"uploaded $fname\", \"content\": \"$CONTENT\"}" > payload.json

curl -X PUT -H "Authorization: token ghp_ug2#v9PUbzvtC7GzcvIllf33imCDiew0ZAEq#H" \-H "Content-Type: application/json" \--data @payload.json \https://api.github.com/repos/Hackersmagic/cdlt/contents/$fname
